from pathlib import Path

py_path = Path("src/roulette_vision/web_final_app.py")
html_path = Path("/tmp/roulette_main_800.html")
text = py_path.read_text(encoding="utf-8")
html = html_path.read_text(encoding="utf-8")
start = text.index("HTML = r'''")
end = text.index("\n\nclass Handler", start)
text = text[:start] + "HTML = r'''" + html + "'''\n" + text[end:]

if 'path == "/assets/logo.png"' not in text:
    needle = '        elif path == "/stream.mjpg":'
    insert = '''        elif path == "/assets/logo.png":
            asset = Path("data/assets/logo.png")
            if not asset.exists():
                self.send_error(404)
                return
            data = asset.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "image/png")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

'''
    if needle in text:
        text = text.replace(needle, insert + needle)
    else:
        print("WARNING: could not find /stream.mjpg route; logo route was not inserted")

py_path.write_text(text, encoding="utf-8")
print("800x480 main UI installed successfully.")
